# -*- coding: utf-8 -*-
"""
Created on Mon Mar 16 17:37:39 2015
Global soundwaves and thermal instability with normalized density profile for a realistic cluster.
Gravity used.

@author: prakriti
"""

from __future__ import division
import numpy as np
from scipy.linalg import eig
from scipy.special import eval_chebyt, eval_chebyu
import matplotlib.pyplot as plt
import sys
import os


def T(r,n):
    a = float(sys.argv[2])/float(sys.argv[3])
    b = 1.
    return eval_chebyt(n, (2*(r-a)/(b-a)) - 1. )        #Chebyshev polynomials of first kind

def U(r,n):
    a = float(sys.argv[2])/float(sys.argv[3])
    b = 1.
    return eval_chebyu(n, (2*(r-a)/(b-a)) - 1.)        #Chebyshev polynomial of second kind

def dTdr(r,n):
    a = float(sys.argv[2])/float(sys.argv[3])
    b = 1.
    if r==b:
        return (n**2)/(b-a)
    elif r==a:
        return ((-1)**(n-1))*(n**2)/(b-a)
    else:
        return n*(U(r,n-1))/(b-a)   

def d2Tdr2(r,n):
    a = float(sys.argv[2])/float(sys.argv[3])
    b = 1.
    if r==b:
        return (n**4 - n**2)/3.0/(b-a)**2
    elif r==a:
        return ((-1)**n)*((n**4 - n**2)/3.0)/(b-a)**2
    else:
        return (n*((n+1)*T(r,n) - U(r,n))/(r**2 - 1))/(b-a)**2
        
N=int(sys.argv[1])
Kpc = 3.086*(10**21)
ga = 5./3.                        #Number of G-L grid points
a = float(sys.argv[2])/float(sys.argv[3])
b = 1.
rb = float(sys.argv[3])*Kpc
eval_growth = []
index_growth = []

grid = np.zeros(N)
r_ar = np.zeros(N)
for i in np.arange(N):
    grid[i] = np.cos(i*np.pi/(N-1))
    r_ar[i] = ((b-a)*(grid[i] + 1.)/2) + a  #r= r/r_cluster
    
#______________________________EQUILIBRIUM______________________________
    
data = np.loadtxt("./eq_data_abN"+str(float(sys.argv[2]))+"_"+str(float(sys.argv[3]))+"_"+str(N)+".dat", usecols=[])
g = data[:,0]
d = data[:,5]
d_p = data[:,6]
p = data[:,7]
p_p = data[:,8]
s = data[:,9]
BV2 = data[:,11]
tcool = data[:,12]
dlnlamdlnT = data[:,13]
da = d[N-1] 
pa = p[N-1]
va = (pa/da)**0.5 
sa = (pa/da**ga)
d = d/da
p = p/pa 
s = s/sa
BV2 = BV2/(va**2/rb**2)
d_p = d_p*rb/da
g = g*rb/va**2
p_p = p_p*rb/pa
tcool = tcool/(rb/va)

#_______________________EIGENPROBLEM____________________________________

M11 = np.zeros([N,N],dtype=complex)
M22 = np.zeros([N,N],dtype=complex)
M33 = np.zeros([N,N],dtype=complex)
M44 = np.zeros([N,N],dtype=complex)
M0 = np.zeros([N,N],dtype=complex)

for i in np.arange(1,N-1):
    for j in np.arange(N):
        M11[i,j] = T(r_ar[i],j)
        M22[i,j] = T(r_ar[i],j)
        M33[i,j] = T(r_ar[i],j)        
        M44[i,j] = T(r_ar[i],j)        
        
            
M1 = np.column_stack([M11,M0,M0,M0])
M2 = np.column_stack([M0,M22,M0,M0])
M3 = np.column_stack([M0,M0,M33,M0])
M4 = np.column_stack([M0,M0,M0,M44])
M = np.row_stack([M1,M2,M3,M4])           
 
L11 = np.zeros([N,N], dtype=complex) 
L22 = np.zeros([N,N], dtype=complex)
L12 = np.zeros([N,N], dtype=complex)
L14 = np.zeros([N,N], dtype=complex)
L21 = np.zeros([N,N], dtype=complex)
L13 = np.zeros([N,N], dtype=complex)
L23 = np.zeros([N,N], dtype=complex)
L24 = np.zeros([N,N], dtype=complex)
L33 = np.zeros([N,N], dtype=complex)
L34 = np.zeros([N,N], dtype=complex)
L31 = np.zeros([N,N], dtype=complex)
L33 = np.zeros([N,N], dtype=complex)
L32 = np.zeros([N,N], dtype=complex)
L41 = np.zeros([N,N], dtype=complex)
L43 = np.zeros([N,N], dtype=complex)
L42 = np.zeros([N,N], dtype=complex)
L44 = np.zeros([N,N], dtype=complex)


l = int(sys.argv[6])
#for j in np.arange(N):
#    L11[0,j] = T(r_ar[0],j)
#    L11[N-1,j] = T(r_ar[N-1],j)
for i in np.arange(1,N-1):
    for j in np.arange(N):
        L12[i,j] = -(dTdr(r_ar[i],j) + (2.*T(r_ar[i],j)/r_ar[i])) - T(r_ar[i],j)*d_p[i]/d[i]
        L13[i,j] = l*(l+1)*T(r_ar[i],j)/r_ar[i]
for j in np.arange(N):
    L22[0,j] = T(r_ar[0],j)
#    L22[N-1,j] = T(r_ar[N-1],j)
for i in np.arange(1,N-1):
    for j in np.arange(N):
        L21[i,j] = -(ga*p[i]*dTdr(r_ar[i],j)/d[i]) - (ga*p_p[i]*T(r_ar[i],j)/d[i]) - g[i]*T(r_ar[i],j)
        L24[i,j] = -(p[i]*dTdr(r_ar[i],j)/d[i]) - (p_p[i]*T(r_ar[i],j)/d[i])
for j in np.arange(N):
    L33[0,j] = T(r_ar[0],j)
    L33[N-1,j] = dTdr(r_ar[N-1],j)
for i in np.arange(1,N-1):
    for j in np.arange(N):
        L34[i,j] = -(p[i]*T(r_ar[i],j)/(r_ar[i]*d[i]))
        L31[i,j] = -(ga*p[i]*T(r_ar[i],j)/(r_ar[i]*d[i]))
for j in np.arange(N):
    L44[N-1,j] = T(r_ar[N-1],j)
#    L44[0,j] = T(r_ar[0],j)
for i in np.arange(1,N-1):
    for j in np.arange(N):
        L42[i,j] = -ga*BV2[i]*T(r_ar[i],j)/g[i]
        L41[i,j] = -(2. + ((ga-1)*dlnlamdlnT[i]))*T(r_ar[i],j)/tcool[i]
        L44[i,j] = -(dlnlamdlnT[i]*T(r_ar[i],j)/tcool[i])
    
L1 = np.column_stack([L11,L12,L13,L14])
L2 = np.column_stack([L21,L22,L23,L24])  
L3 = np.column_stack([L31,L32,L33,L34]) 
L4 = np.column_stack([L41,L42,L43,L44])     
L = np.row_stack([L1,L2,L3,L4])

vals,vecs = eig(L,M)                 #vals-->eigenvalues, vecs-->eigenvectors
#print vals
vals_good=np.sort(abs(vals.imag))
index = np.argsort(abs(vals.imag))

for i in np.arange(4*N):
    if vals[index[i]].real>1.e-4 and vals[index[i]].real<1.e2:
        eval_growth.append(vals[index[i]])
        index_growth.append(i)
        
eval_growth = np.array(eval_growth)
index_growth = np.array(index_growth)

data_eig = np.zeros([len(eval_growth),3])
data_eig[:,0] = index_growth
data_eig[:,1] = eval_growth.real
data_eig[:,2] = eval_growth.imag
np.savetxt("growth_abN_"+str(float(sys.argv[2]))+"_"+str(float(sys.argv[3]))+"_"+str(N)+".dat",data_eig)



#-------------------------------Plotting Eigenmodes---------------------------------------
#NN1 = 2000
#NN2 = 1000
#NN = NN1 + NN2
#c = .1
Mat0 = np.zeros([N,N])
Mat11 = np.zeros([N,N])
Mat22 = np.zeros([N,N])
Mat33 = np.zeros([N,N])
Mat44 = np.zeros([N,N])

#r_new1 = np.linspace(a,c,num=NN1)
#r_new2 = np.linspace(c,b,NN2)
#r_new = np.zeros(NN)
#for i in np.arange(NN1):
#    r_new[i] = r_new1[i]
#for i in np.arange(NN2):
#    r_new[NN1+i] = r_new2[i]


for i in np.arange(N):
    for j in np.arange(N):
        Mat11[i,j] = T(r_ar[i],j)
        Mat22[i,j] = T(r_ar[i],j)
        Mat33[i,j] = T(r_ar[i],j)
        Mat44[i,j] = T(r_ar[i],j)
                  
Mat1 = np.column_stack([Mat11,Mat0,Mat0,Mat0])
Mat2 = np.column_stack([Mat0,Mat22,Mat0,Mat0])
Mat3 = np.column_stack([Mat0,Mat0,Mat33,Mat0])
Mat4 = np.column_stack([Mat0,Mat0,Mat0,Mat44])
Mat = np.row_stack([Mat1,Mat2,Mat3,Mat4])        




m1 = int(sys.argv[4])
if m1==1:
    vals_data = np.zeros([4*N,3])
    for ii in np.arange(4*N):
        vals_data[ii,0] = ii
        vals_data[ii,1] = vals[index[ii]].real
        vals_data[ii,2] = vals[index[ii]].imag
        np.savetxt("eigenvalues_abN_"+str(float(sys.argv[2]))+"_"+str(float(sys.argv[3]))+"_"+str(N)+".dat", vals_data)
        
  
m2 = int(sys.argv[5])
eig_mode_ini = int(sys.argv[7])
eig_mode_fin = int(sys.argv[8])

if m2 == 1:
    if not os.path.exists("./a_b_N_"+str(float(sys.argv[2]))+"_"+str(float(sys.argv[3]))+"_"+str(N)):
        os.makedirs("./a_b_N_"+str(float(sys.argv[2]))+"_"+str(float(sys.argv[3]))+"_"+str(N)) 
#    if not os.path.exists("./dsdr_a_b_N_"+str(float(sys.argv[2]))+"_"+str(float(sys.argv[3]))+"_"+str(N)):
#        os.makedirs("./dsdr_a_b_N_"+str(float(sys.argv[2]))+"_"+str(float(sys.argv[3]))+"_"+str(N))     
    for ii in np.arange(eig_mode_ini,eig_mode_fin):
        t=0
        soln = np.dot(Mat,vecs[:,index[ii]])
        fin_sol = np.zeros(4*N, dtype=complex)
        fin_sol = (np.exp(vals[index[ii]]*t))*soln
        eigenf = np.zeros([4*N,2])
        eigenf[:,0] = fin_sol.real
        eigenf[:,1] = fin_sol.imag
        np.savetxt('./a_b_N_'+str(float(sys.argv[2]))+'_'+str(float(sys.argv[3]))+'_'+str(N)+'/eigfunc_g'+str(ii)+'.dat',eigenf) 
        plt.figure(figsize=[12,10])
        plt.subplot(411)
        plt.plot(r_ar,fin_sol[0:N].real, 'g')
        plt.plot(r_ar,fin_sol[0:N].imag, 'g--')
        plt.xlim([a,b])
        plt.xscale("log")
        plt.ylabel(r'$\frac{R_{\rho}}{\rho_0}$',fontsize=22)
        plt.tick_params(labelsize=14)
        plt.title(r'$\sigma R_2/v_{sc} = %.4f+ i %.4f$' %(vals[index[ii]].real, vals[index[ii]].imag))
        plt.subplot(412)
        plt.plot(r_ar,fin_sol[N:2*N].real, 'k')
        plt.plot(r_ar,fin_sol[N:2*N].imag, 'k--')
        plt.xlim([a,b])
        plt.xscale("log")
        plt.ylabel(r'$R_r$',fontsize=20)
        plt.tick_params(labelsize=14)
        plt.subplot(413)
        plt.plot(r_ar,fin_sol[2*N:3*N].real, 'r')
        plt.plot(r_ar,fin_sol[2*N:3*N].imag, 'r--')
        plt.xlim([a,b])
        plt.xscale("log")
        plt.ylabel(r'$R_{\theta}$',fontsize=20)
        plt.tick_params(labelsize=14)
        plt.subplot(414)
        plt.plot(r_ar,fin_sol[3*N:4*N].real, 'm')
        plt.plot(r_ar,fin_sol[3*N:4*N].imag, 'm--')
        plt.xlim([a,b])
        plt.xscale("log")
        plt.ylabel(r'$\frac{R_s}{s_0}$',fontsize=22)
        plt.xlabel(r'$r/R_2$',fontsize=20)
        plt.tick_params(labelsize=14)
        plt.savefig('./a_b_N_'+str(float(sys.argv[2]))+'_'+str(float(sys.argv[3]))+'_'+str(N)+'/eigfunc'+str(ii)+'.png')

        plt.show()
        
"""TO PLOT DENSITY PERTURBATION FOR SEVERAL EIGENFUNCTIONS"""

#soln1 = np.zeros([4*NN,10], dtype=complex)
#vals1 = np.zeros(10,dtype=complex)
#soln1[:,0] = np.dot(Mat,vecs[:,index[500]])
#vals1[0] = vals[index[500]]
#soln1[:,1] = np.dot(Mat,vecs[:,index[497]])
#vals1[1] = vals[index[497]]
#soln1[:,2] = np.dot(Mat,vecs[:,index[496]])
#vals1[2] = vals[index[496]]
#soln1[:,3] = np.dot(Mat,vecs[:,index[493]])
#vals1[3] = vals[index[493]]
#soln1[:,4] = np.dot(Mat,vecs[:,index[492]])
#vals1[4] = vals[index[492]]
#soln1[:,5] = np.dot(Mat,vecs[:,index[489]])
#vals1[5] = vals[index[489]]
#soln1[:,6] = np.dot(Mat,vecs[:,index[488]])
#vals1[6] = vals[index[488]]
#soln1[:,7] = np.dot(Mat,vecs[:,index[485]])
#vals1[7] = vals[index[485]]
#
#plt.figure()
#for i in np.arange(8):
#    plt.subplot(4,2,i+1)
#    plt.plot(r_new,soln1[0:NN,i].real, 'r')
#    plt.plot(r_new,soln1[0:NN,i].imag, 'r--')
#    plt.xlim([a,b])
#    plt.xscale("log")
#    plt.ylabel(r'$\frac{R_{\rho}}{\rho_0}$',fontsize=16)
#    plt.xlabel(r'$r/R_2$',fontsize=16)
#    plt.tick_params(labelsize=12)
#    plt.text(.07,1.5,r'$\sigma R_2/v_{sc} = %.4f+ i %.4f$' %(vals1[i].real, vals1[i].imag),fontsize=12)
#plt.show()
##    
    
    
"""TO PRINT AN EIGENFUNCTION"""    
#for ii in np.arange(482,483):
#    t=0
#    eigfunc = np.zeros([4*NN,2])
#    soln = np.dot(Mat,vecs[:,index[ii]])
#    fin_sol = np.zeros(4*NN, dtype=complex)
#    fin_sol = (np.exp(vals[index[ii]]*t))*soln
#    eigfunc[:,0] = fin_sol.real
#    eigfunc[:,1] = fin_sol.imag
#    np.savetxt("eigfuncdata"+str(ii)+"_"+str(N)+".dat",eigfunc)
#   


"""TO PLOT DERIVATIVES OF EIGEN FUNCTIONS IF REQUIRED"""
#    for i in np.arange(1000):
#        for j in np.arange(N):
#            Mat44[i,j] = dTdr(r_new[i],j)
                  
#    Mat4 = np.column_stack([Mat0,Mat0,Mat0,Mat44])
#    Mat = np.row_stack([Mat1,Mat2,Mat3,Mat4]) 
#    
#    for ii in np.arange(4*N):
#        t=0
#        soln = np.dot(Mat,vecs[:,index[ii]])
#        fin_sol = np.zeros(4000, dtype=complex)
#        fin_sol = (np.exp(vals[index[ii]]*t))*soln
#        plt.figure()
#        plt.plot(r_new,fin_sol[3000:4000].real, 'r')
#        plt.plot(r_new,fin_sol[3000:4000].imag, 'r--')
#        plt.xlim([a-.005,b])
#        plt.savefig('./dsdr_a_b_N_'+str(float(sys.argv[2]))+'_'+str(float(sys.argv[3]))+'_'+str(N)+'/eigfunc'+str(ii)+'.png')
#        plt.clf()
#        
        
#        plt.show()