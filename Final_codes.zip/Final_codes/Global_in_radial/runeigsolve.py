"""
@author: prakriti
"""

import numpy as np
import matplotlib.pyplot as plt
import os


Kpc = 3.086*(10**21)
fig=plt.figure(figsize=[10,8])

"""ENTER THE NUMBER OF G-L POINTS."""

N1=200
N2=401
diff=200

for N in np.arange(N1,N2,diff):
    
    

    """ENTER TWO BOUNDARIES IN RADIAL DIRECTION. a<b GIVE IN Kpc."""
    a = .1
    b = 100.0
    """------------------------------------------------------------------------"""
    
    """NOTE: m1 = 1 will produce eigvalues data file. Else m1=0."""
    m1 = 1

    """------------------------------------------------------------------------"""
    
    """NOTE: m2 = 1 will save the eigenfunction plots in a directory. Else m2=0."""
    m2 = 0
    eig_mode_ini = 393    #All eigen functions from eig_mode_ini to eig_mode_fin will be saved. (For N=200, the first eigenmode comes at 393rd position.)
    eig_mode_fin = 394
    """------------------------------------------------------------------------"""
    
    
    
    k_perp = 100.
    os.system("python eq.py "+str(N)+" "+str(a)+" "+str(b))
    os.system("python eigsolve.py "+str(N)+" "+str(a)+" "+str(b)+" "+str(m1)+" "+str(m2)+" "+str(k_perp)+" "+str(eig_mode_ini)+" "+str(eig_mode_fin))
    
    
    if m1 == 1:
        vals_data = np.loadtxt("eigenvalues_abN_"+str(a)+"_"+str(b)+"_"+str(N)+".dat",usecols=[])
        vals1 = vals_data[:,1]
        vals2 = vals_data[:,2]
    
    
    """EQUILIBRIUIM PROFILES(Can be used for plotting. Note equilibrium profiles have been saved in cgs units):"""
    
    data = np.loadtxt("./eq_data_abN"+str(a)+"_"+str(b)+"_"+str(N)+".dat", usecols=[])
    g = data[:,0]                  #gravitational acceleration
    d = data[:,5]                  #density(rho)
    d_p = data[:,6]                #d(\rho)/dr
    p = data[:,7]                  #pressure(p)
    p_p = data[:,8]                #dp/dr
    s = data[:,9]                  #entropy
    BV2 = data[:,11]               #Brunt-Vaisala frequency
    tcool = data[:,12]             #cooling time
    dlnlamdlnT = data[:,13]        #dlog(\lamda)/dlog(T)
    tff = data[:,14]               #free-fall time
    r = data[:,15]                 #radial grid
    
    #Additionally lambda(cooling function) and ds/dr can also be read from the same file. In eq.py one can find out which columns have these quantities.
    
    """All the equilibrium quantities that go into the eigen problem are scaled by these factors"""
    da = d[N-1]        
    pa = p[N-1]
    va = (pa/da)**0.5 
    rb = b*Kpc
    """-----------------------------------------------------------------------------------------"""
    """position of minimum tcool/tff"""
    temp = min(tcool/tff)
    pos = np.where(tcool/tff==temp)   
    
    """position of maximum Brunt-Vaisala frequency"""
    temp1 = max(BV2)
    pos1 = np.where(BV2==temp1)       
    
    """Scaling"""
    tcool = tcool/(rb/va)             
    tff = tff/(rb/va)
    BV2 = BV2/(va/rb)**2
    """------------------"""
    
    gamma = 5./3.
    t_TI = gamma*tcool/(2.-dlnlamdlnT)
    t_TI_pos = t_TI[pos]
    
    
    """PLOT EIGENVALUES IN COMPLEX PLANE"""

    if m1 == 1:
        ax=fig.add_axes([.1,.1,.85,.85])
        marker=['o','*'] #Note that marker is of 2 kinds one has to put more markers to plot eigenvalues for a number of resolutions(>2)
        a=ax.plot(abs(vals1)*tcool[pos],abs(vals2)/(BV2[pos1])**0.5,marker[(N-N1)/diff], markersize=10, label="n="+str(N))
        markeredgecolor='none'
        plt.ylim(0.005,2)
        plt.xlim(.02,2)
        plt.xscale("log")
        plt.yscale("log")
        plt.legend(loc='lower right')
        ax.set_xlabel(r'$\mathbf{Re(\sigma){t_{cool}}}$',fontsize=20)
        ax.set_ylabel(r'$\mathbf{Im(\sigma)/max({\sigma}_{BV})}$',fontsize=20)
        
        
plt.show()


   





    



   