"""
@author: prakriti
"""

from __future__ import division
import numpy as np
from scipy.integrate import odeint
import sys
#Produces a data file for a specific given N no. of grid points. 

def K(r):
	Kpc = 3.086*(10**21)
	K0 = 8.0
	K100 = 80.0
	alpha = 1.1
	return K0 + K100*((r/(100.0*Kpc)))**alpha

def dKdr(r):
  	Kpc = 3.086*(10**21)
  	K100 = 80.0
	alpha = 1.1
	return K100*((r/(100.0*Kpc))**alpha)*(alpha/r)

def g(r):
    Kpc = 3.086*(10**21)
    rs = 485.758*Kpc
    M200 = 1.0375*(10**48)
    G = 6.67*(1e-8)
    b = 2*M200*G/1.38
    return b*(np.log(1 +r/rs)/(r*r) - (1/(r*(rs+r)))) 

def derv1(n,r):
    mue = 1.17
    mu = 0.62
    ga = 5/3
    mp = 1.6726*(1e-24)
    kev = 1.16e07
    kb = 1.38*(1e-16)
    return (-((n)/(ga*K(r)))*((((mue**(ga-1))*mp*g(r)*(n**(1-ga)))/(kev*kb*(mu**(ga-2)))) + dKdr(r)))


N = int(sys.argv[1])     
Kpc = 3.086*(10**21)
mue = 1.17
mu = .62
ga = 5./3
kev = 1.16e07
c = (mu/mue)**(ga-1)
a = float(sys.argv[2])
b = float(sys.argv[3])

#FINDS NUMBER DENSITY AT b*Kpc---------------------------------------------------
n1600 = 1.e-4
r_bound = np.linspace(1600.*Kpc,b*Kpc,num=1000)
if b>1600:
    print("ERROR! boundary should be less than 1600Kpc")
elif b == 1600:
    nbound = n1600
else:
    sol_bound = odeint(derv1,n1600,r_bound,mxstep=5000000)[:,0]
    nbound = sol_bound[999]
#--------------------------------------------------------------------------------    

kb = 1.38*(1e-16)
mp = 1.6726*(1e-24)
c1 = kb/(mu*mp)

e = 4.8*(1e-10) #statcoulomb= (erg^1/2)-(cm^1/2)
m_e = 9.1094*(1e-28) #in gm
h = 6.626*(1e-27) #erg-sec
clight = 3*(1e10)

c2 = (32*np.pi*(e**6)/(3*h*m_e*(clight**3)))*(2*np.pi*kb/(3*m_e))**0.5

#GAUSS-LOBATTO GRID--------------------------------------------------------------
grid = np.zeros(N)
r_ar = np.zeros(N)
for i in np.arange(N):
    grid[i] = np.cos(i*np.pi/(N-1)) 
    r_ar[i] = (b-a)*Kpc*(grid[i]+1)/2 + (a*Kpc)
#--------------------------------------------------------------------------------
if b<=1600:
    
    sol_n = odeint(derv1,nbound,r_ar,mxstep=5000000)[:,0]
    
    nprime = np.zeros(len(sol_n))
    for i in np.arange(len(sol_n)):
    	nprime[i] = derv1(sol_n[i], r_ar[i])
    
    
    temp = np.zeros(len(sol_n))     #in Kelvin
    for i in np.arange(len(sol_n)):
           temp[i] = (c*kev)*K(r_ar[i])*(sol_n[i])**(ga-1)
    
    dtemp = np.zeros(len(sol_n))     #in Kelvin
    for i in np.arange(len(sol_n)):
           dtemp[i] = (c*kev)*dKdr(r_ar[i])*(sol_n[i])**(ga-1) + (ga-1)*(c*kev)*K((r_ar[i]))*derv1(sol_n[i],r_ar[i])*(sol_n[i])**(ga-2)
    
    rho = np.zeros(len(sol_n))
    for i in np.arange(len(sol_n)):
    	rho[i] = mu*mp*sol_n[i]
    
    drho = np.zeros(len(sol_n))
    for i in np.arange(len(sol_n)):
    	drho[i] = mu*mp*nprime[i]
    
    pres = np.zeros(len(sol_n))
    for i in np.arange(len(sol_n)):
    	pres[i] = kb*sol_n[i]*temp[i]
    
    dpres = np.zeros(len(sol_n))
    for i in np.arange(len(sol_n)):
    	dpres[i] = kb*temp[i]*nprime[i] + kb*sol_n[i]*dtemp[i]
    
    entr = np.zeros(len(sol_n))
    for i in np.arange(len(sol_n)):
    	entr[i] = pres[i]/((rho[i])**ga)
    
    dentr = np.zeros(len(sol_n))
    for i in np.arange(len(sol_n)):
    	dentr[i] = dpres[i]/((rho[i])**ga) - pres[i]*ga*drho[i]/((rho[i])**(ga+1))
    
    BVfreqsq = np.zeros(len(sol_n))
    for i in np.arange(len(sol_n)):
    	BVfreqsq[i] = (g(r_ar[i])/ga)*(dentr[i]/entr[i])
    
    t_cool = np.zeros(len(sol_n))
    tff = np.zeros(len(sol_n))
    coolfunc = np.zeros(len(sol_n))
    
    for i in np.arange(len(sol_n)):
        coolfunc[i] = (1.e-22)*((8.6e-3)*((temp[i]/kev)**(-1.7)) + (.058*(temp[i]/kev)**0.5) + .063)
        t_cool[i] = (pres[i])/((ga-1)*(rho[i]/(mp*mue))*(sol_n[i]-(rho[i]/(mp*mue)))*coolfunc[i])
        tff[i] = (2*r_ar[i]/g(r_ar[i]))**0.5
        
    dlnlamdlnT = np.zeros(len(sol_n))
    for i in np.arange(len(sol_n)):
        dlnlamdlnT[i] = temp[i]*(1.e-22)*(((8.6e-3)*(-1.7)*((1/kev)**(-1.7))*(temp[i]**(-2.7))) + (0.058*0.5*((1/kev)**0.5)*(temp[i]**(-0.5))))/coolfunc[i]
        
    
    full_data = np.zeros([N,16])
    t_cool_BVsq = np.zeros([N,2])
    for i in np.arange(N):
            full_data[i,0] = g(r_ar[i])
            full_data[i,1] = sol_n[i] 
            full_data[i,2] = nprime[i]        
            full_data[i,3] = temp[i]          
            full_data[i,4] = dtemp[i]         
            full_data[i,5] = rho[i]            
            full_data[i,6] = drho[i]          
            full_data[i,7] = pres[i]          
            full_data[i,8] = dpres[i]         
            full_data[i,9] = entr[i]           
            full_data[i,10] = dentr[i]        
            full_data[i,11] = BVfreqsq[i]     
            full_data[i,12] = t_cool[i]        
            full_data[i,13] = dlnlamdlnT[i]
            full_data[i,14] = tff[i]
            full_data[i,15] = r_ar[i]
         

    np.savetxt("./eq_data_abN"+str(float(sys.argv[2]))+"_"+str(float(sys.argv[3]))+"_"+str(N)+".dat",full_data)

